$(".home-panel-close").click(function () {
    $(this).parent().parent().parent().fadeOut(200);
});