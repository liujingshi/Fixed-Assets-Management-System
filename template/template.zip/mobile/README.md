# 移动端模板文件夹

## 放置移动端界面设计、html等

* FixedAssetsManagementSystem 文件夹是5+App项目MUI框架
